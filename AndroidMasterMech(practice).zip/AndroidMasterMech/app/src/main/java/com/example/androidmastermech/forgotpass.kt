package com.example.androidmastermech

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class forgotpass : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgotpass)
    }
}
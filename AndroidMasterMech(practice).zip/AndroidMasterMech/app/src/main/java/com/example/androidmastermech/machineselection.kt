package com.example.androidmastermech

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class machineselection : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_machineselection)

        var optpage = findViewById<Button>(R.id.entroptr)
        optpage.setOnClickListener {
            // Code to be executed when the operatnew is clicked
            val intent = Intent(this, newoperator::class.java)
            startActivity(intent)
    }
}
}
